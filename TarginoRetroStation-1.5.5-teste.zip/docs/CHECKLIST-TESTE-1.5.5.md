# Checklist de teste - 1.5.5 (marque cada item)

Antes: faca copia de TarginoRetroStation\Dados (favoritos, indices). Teste numa pasta Hydra de teste, se possivel.

## A. Inicio e versao
- [ ] Abre pelo atalho sem janela de erro.
- [ ] Logs\launcher.log comeca com "Launcher iniciado - v1.5.5" e nao tem linhas ERRO novas.
- [ ] Modo desenvolvedor: titulo mostra v1.5.5.

## B. Remocao do Telegram
- [ ] Menu do botao direito num jogo: Jogar/Fechar jogo, Favoritar, Personalizar launcher.
- [ ] Menu de um sistema (tela Sistemas) abre e entra no sistema.
- [ ] Personalizar > aba Compactados: so aparecem UnRAR e pastas; NAO aparecem tdl/Telegram.
- [ ] Personalizar > textos: abre sem erro (itens "baixando"/"cancelar download" sumiram).
- [ ] Jogar um jogo e fechar o launcher com o jogo aberto: sem erro no log.

## C. Capas
- [ ] Abre a biblioteca: capas existentes continuam; nenhuma capa baixada some.
- [ ] Rode tools\Gerar-Relatorio-Capas.ps1 -Root "<pasta hydra>": gera o .md e o modelo .json.
- [ ] Preencha 1 alias de teste, salve como Dados\hydra-capas-aliases.json, reabra: o jogo ganha capa (ou mantem arte do sistema se o nome nao existir).
- [ ] Alias com JSON invalido (apague uma aspa): o programa abre normalmente e usa so os aliases embutidos.
- [ ] Apague o aliases.json: jogos continuam como antes.

## D. Atualizador (sem instalar nada!)
- [ ] Filtros > Verificar atualizacoes: com 1.5.5 local e release 1.5.4 publicada, mostra "ja esta na versao estavel mais recente".
- [ ] Teste da janela de progresso e do Cancelar (nao instala):
      mkdir %TEMP%\rs-job
      powershell -STA -NoProfile -ExecutionPolicy Bypass -File "<pasta>\TarginoRetroStation\RetroStationUpdateWorker.ps1" -Root "<pasta hydra>" -Installed 1.5.3 -Job "%TEMP%\rs-job" -LauncherPid 0
      Na janela "Nova versao" clique "Atualizar agora": deve aparecer o progresso em MB. CLIQUE EM CANCELAR antes de terminar (se terminar, o Setup 1.5.4 sera aberto: feche-o sem instalar).
- [ ] Apos Cancelar: nenhuma mensagem de erro; %TEMP%\rs-job\error.txt NAO existe.
- [ ] Sem internet: mensagem "Nao foi possivel verificar/baixar... Nada foi instalado".

## E. Instalador
- [ ] Build.ps1 conclui sem erro; Setup.exe e WebSetup.exe gerados.
- [ ] Instala por cima da 1.5.4 mantendo favoritos, capas, musicas, saves.
- [ ] Antivirus nao bloqueia (anote o nome da deteccao se bloquear).

## Antes de publicar
- [ ] Todos os itens acima OK.
- [ ] Gerar update.json assinado SOMENTE depois de assinar/gerar o instalador final (hash do arquivo definitivo).
- [ ] Atualizar README: versao 1.5.5 e remover/ajustar "A versao atual e 1.5.2".
